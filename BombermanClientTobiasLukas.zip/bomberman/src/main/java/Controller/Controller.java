package Controller;

public class Controller {

    public int returnOne(){
        return 1;
    }
}
