package Model;

/**
 * Created by lukas on 08.11.2016.
 */
public class GameElement {

    private byte[] graphics;
    private float size;

    public GameElement(byte[] graphics, float size) {
        this.graphics = graphics;
        this.size = size;
    }

    public void draw(){

    }
}
