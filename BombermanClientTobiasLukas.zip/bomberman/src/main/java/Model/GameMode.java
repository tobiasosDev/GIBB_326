package Model;

/**
 * Created by lukas on 08.11.2016.
 */
public class GameMode {

    private double time;
    private int rounds;

    public GameMode(double time, int rounds) {
        this.time = time;
        this.rounds = rounds;
    }
}
