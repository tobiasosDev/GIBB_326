package Model;

public interface PlayerFunctionsImp{
        public void action();
}
