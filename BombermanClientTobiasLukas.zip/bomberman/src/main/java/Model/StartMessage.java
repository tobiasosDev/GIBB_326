package Model;

/**
 * Created by tobiasluscher on 16.11.16.
 */
public class StartMessage {
    String command;
    String name;


}
