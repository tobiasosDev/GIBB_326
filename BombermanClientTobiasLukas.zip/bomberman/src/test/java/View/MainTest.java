package View;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by tobiasluscher on 26.10.16.
 */
public class MainTest {
    @Test
    public void start() throws Exception {

    }

    @Test
    public void main() throws Exception {

    }

}